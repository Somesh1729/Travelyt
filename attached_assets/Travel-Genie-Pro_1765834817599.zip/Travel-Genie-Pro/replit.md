# TravelGenie

## Overview

TravelGenie is an AI-powered travel booking platform that helps users discover destinations, plan trips, and make bookings. The application provides a modern, visually appealing interface for browsing travel destinations, viewing trip details, and managing reservations. The platform combines destination search, user authentication, and booking management into a seamless travel planning experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript/JSX hybrid approach
- **Build Tool**: Vite with custom plugins for meta images and Replit integration
- **Styling**: Tailwind CSS v4 with custom theme variables (ocean & sunset color palette)
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack React Query for server state and data fetching
- **Fonts**: DM Sans (body) and Outfit (display) from Google Fonts
- **Path Aliases**: `@/` for client source, `@shared/` for shared code, `@assets/` for attached assets

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Authentication**: Passport.js with local strategy, bcryptjs for password hashing
- **Session Management**: express-session with PostgreSQL session store (connect-pg-simple)
- **API Structure**: RESTful endpoints prefixed with `/api`

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with drizzle-zod for schema validation
- **Schema Location**: `shared/schema.ts` (TypeScript) and `shared/schema.js` (JavaScript)
- **Migrations**: Managed via `drizzle-kit push` command

### Database Schema
The application uses three main tables:
1. **users**: User accounts with authentication credentials (id, username, email, password, firstName, lastName)
2. **destinations**: Travel destinations with details (title, location, description, price, rating, image, featured, duration, highlights, included items)
3. **bookings**: User bookings linking users to destinations (userId, destinationId, dates, guests, totalPrice, status, specialRequests)

### Build System
- **Development**: `tsx` for running TypeScript server, Vite dev server for frontend
- **Production**: Custom build script using esbuild for server bundling, Vite for client
- **Output**: Combined bundle in `dist/` directory with `dist/public` for static assets

### Code Organization
```
├── client/           # Frontend React application
│   ├── src/
│   │   ├── components/ui/  # shadcn/ui components
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utility functions and query client
├── server/           # Backend Express application
│   ├── index.ts      # Main entry point (TypeScript)
│   ├── routes.ts     # API route definitions
│   ├── storage.ts    # Data access layer
│   └── auth.js       # Passport authentication setup
├── shared/           # Shared code between frontend and backend
│   └── schema.ts     # Drizzle database schema and types
```

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Database queries and schema management
- **connect-pg-simple**: Session storage in PostgreSQL

### Authentication
- **Passport.js**: Authentication middleware with local strategy
- **bcryptjs**: Password hashing
- **express-session**: Session management

### UI/Frontend
- **Radix UI**: Accessible component primitives (dialogs, menus, forms, etc.)
- **TanStack React Query**: Data fetching and caching
- **Tailwind CSS**: Utility-first styling
- **Lucide React**: Icon library
- **react-day-picker**: Calendar component
- **embla-carousel-react**: Carousel functionality
- **vaul**: Drawer component
- **cmdk**: Command palette
- **recharts**: Charts and data visualization

### Build Tools
- **Vite**: Frontend build and development server
- **esbuild**: Server-side bundling for production
- **tsx**: TypeScript execution for development

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Secret key for session encryption (defaults to development value)