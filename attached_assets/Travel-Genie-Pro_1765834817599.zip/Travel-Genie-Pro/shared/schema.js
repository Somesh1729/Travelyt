import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  email: text("email").notNull().unique(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const destinations = pgTable("destinations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  rating: decimal("rating", { precision: 2, scale: 1 }).notNull(),
  image: text("image").notNull(),
  featured: boolean("featured").default(false),
  duration: text("duration"),
  highlights: text("highlights").array(),
  included: text("included").array(),
});

export const insertDestinationSchema = createInsertSchema(destinations).omit({
  id: true,
});

export const bookings = pgTable("bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  destinationId: varchar("destination_id").notNull().references(() => destinations.id),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  guests: integer("guests").notNull(),
  totalPrice: integer("total_price").notNull(),
  status: text("status").notNull().default("pending"),
  specialRequests: text("special_requests"),
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
});
