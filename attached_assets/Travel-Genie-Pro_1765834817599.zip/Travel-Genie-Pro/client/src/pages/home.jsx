import { useState, useEffect } from "react";
import { Link } from "wouter";
import Navbar from "@/components/navbar";
import Hero from "@/components/hero";
import DestinationCard from "@/components/destination-card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Globe, Shield, Zap } from "lucide-react";

export default function Home() {
  const [destinations, setDestinations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDestinations();
  }, []);

  async function fetchDestinations() {
    try {
      const response = await fetch('/api/destinations?featured=true');
      const data = await response.json();
      setDestinations(data.destinations);
    } catch (error) {
      console.error('Failed to fetch destinations:', error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      <Hero />
      
      {/* Popular Destinations Section */}
      <section className="py-20 px-4 container mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">Popular Destinations</h2>
            <p className="text-muted-foreground text-lg max-w-2xl">
              Explore our most visited locations this season. Handpicked for the ultimate travel experience.
            </p>
          </div>
          <Link href="/destinations">
            <Button variant="ghost" className="text-primary hover:text-primary/80 group" data-testid="button-view-all-destinations">
              View All Destinations <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {loading ? (
            <div className="col-span-full text-center py-12 text-muted-foreground">
              Loading destinations...
            </div>
          ) : destinations.length === 0 ? (
            <div className="col-span-full text-center py-12 text-muted-foreground">
              No destinations available
            </div>
          ) : (
            destinations.map((dest, index) => (
              <div key={dest.id} className="animate-in fade-in slide-in-from-bottom-5 duration-700" style={{ animationDelay: `${index * 100}ms` }}>
                <DestinationCard {...dest} rating={parseFloat(dest.rating)} />
              </div>
            ))
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose TravelGenie?</h2>
            <p className="text-lg text-muted-foreground">
              We combine advanced technology with human expertise to deliver seamless travel experiences.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-background p-8 rounded-2xl shadow-sm border border-border/50 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6">
                <Globe className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Global Coverage</h3>
              <p className="text-muted-foreground">
                Access exclusive deals and experiences in over 190 countries worldwide.
              </p>
            </div>
            <div className="bg-background p-8 rounded-2xl shadow-sm border border-border/50 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-secondary/10 rounded-xl flex items-center justify-center text-secondary mb-6">
                <Zap className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Instant Booking</h3>
              <p className="text-muted-foreground">
                Secure your flights and hotels in seconds with our lightning-fast booking engine.
              </p>
            </div>
            <div className="bg-background p-8 rounded-2xl shadow-sm border border-border/50 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-green-500/10 rounded-xl flex items-center justify-center text-green-500 mb-6">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Secure Payments</h3>
              <p className="text-muted-foreground">
                Your financial data is protected with enterprise-grade encryption and fraud prevention.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 container mx-auto px-4">
        <div className="bg-primary rounded-3xl p-8 md:p-16 text-center text-white relative overflow-hidden">
          {/* Abstract circles */}
          <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/10 rounded-full translate-x-1/3 translate-y-1/3 blur-3xl" />
          
          <div className="relative z-10 max-w-2xl mx-auto space-y-6">
            <h2 className="text-3xl md:text-5xl font-bold font-display">Ready to Start Your Journey?</h2>
            <p className="text-white/80 text-lg">
              Join thousands of travelers who have found their perfect getaway with TravelGenie.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/destinations">
                <Button size="lg" variant="secondary" className="font-bold text-base px-8 h-12" data-testid="button-plan-trip">
                  Plan My Trip
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="bg-transparent border-white/30 text-white hover:bg-white/10 font-bold text-base px-8 h-12" data-testid="button-contact-support">
                Contact Support
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2 font-display font-bold text-xl text-primary">
              <Globe className="h-6 w-6" />
              TravelGenie
            </div>
            <div className="text-sm text-muted-foreground">
              © 2024 TravelGenie. All rights reserved.
            </div>
            <div className="flex gap-6">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Privacy</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Terms</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Sitemap</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
