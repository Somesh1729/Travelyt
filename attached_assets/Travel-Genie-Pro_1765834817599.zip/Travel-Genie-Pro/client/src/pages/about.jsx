import Navbar from "@/components/navbar";
import { Globe, Users, Award, Heart } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="pt-24 pb-20 container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 font-display">
              About TravelGenie
            </h1>
            <p className="text-xl text-muted-foreground">
              Making dream vacations a reality since 2024
            </p>
          </div>

          <div className="prose prose-lg max-w-none mb-16">
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              TravelGenie was born from a simple belief: everyone deserves to explore the world's most incredible destinations without the hassle of complex planning and booking.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              We've partnered with the world's best hotels, airlines, and local tour operators to bring you curated travel experiences that combine luxury, authenticity, and value. Our team of travel experts personally visits and vets every destination to ensure you get the best possible experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-muted/30 p-8 rounded-2xl">
              <Globe className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold mb-3">Global Reach</h3>
              <p className="text-muted-foreground">
                With destinations in over 190 countries, we help you discover hidden gems and iconic landmarks across every continent.
              </p>
            </div>

            <div className="bg-muted/30 p-8 rounded-2xl">
              <Users className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold mb-3">Expert Team</h3>
              <p className="text-muted-foreground">
                Our passionate travel specialists bring decades of combined experience to help you plan the perfect getaway.
              </p>
            </div>

            <div className="bg-muted/30 p-8 rounded-2xl">
              <Award className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold mb-3">Award Winning</h3>
              <p className="text-muted-foreground">
                Recognized for excellence in customer service and curated travel experiences by leading industry publications.
              </p>
            </div>

            <div className="bg-muted/30 p-8 rounded-2xl">
              <Heart className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold mb-3">Customer First</h3>
              <p className="text-muted-foreground">
                Your satisfaction is our top priority. We're with you every step of your journey, from booking to safe return home.
              </p>
            </div>
          </div>

          <div className="bg-primary text-white p-12 rounded-3xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 font-display">
              Ready to Start Your Adventure?
            </h2>
            <p className="text-white/90 text-lg mb-6">
              Join thousands of happy travelers who trusted TravelGenie with their dream vacations
            </p>
            <div className="flex flex-wrap gap-8 justify-center text-left">
              <div>
                <div className="text-4xl font-bold mb-1">50K+</div>
                <div className="text-white/80">Happy Travelers</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-1">190+</div>
                <div className="text-white/80">Countries</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-1">98%</div>
                <div className="text-white/80">Satisfaction Rate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
