import { useState, useEffect } from "react";
import { Link } from "wouter";
import Navbar from "@/components/navbar";
import DestinationCard from "@/components/destination-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MapPin } from "lucide-react";

export default function DestinationsPage() {
  const [destinations, setDestinations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    fetchDestinations();
  }, []);

  async function fetchDestinations(query = "") {
    setLoading(true);
    try {
      const url = query 
        ? `/api/destinations?search=${encodeURIComponent(query)}` 
        : '/api/destinations';
      const response = await fetch(url);
      const data = await response.json();
      setDestinations(data.destinations);
    } catch (error) {
      console.error('Failed to fetch destinations:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleSearch = (e) => {
    e.preventDefault();
    fetchDestinations(searchQuery);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="pt-24 pb-20 container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 font-display">
            Discover Your Next Adventure
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Browse our curated collection of dream destinations from around the world
          </p>

          <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search destinations, locations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-4 py-6 text-lg rounded-full"
                data-testid="input-search-destinations"
              />
              <Button 
                type="submit" 
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full"
                data-testid="button-search-destinations"
              >
                Search
              </Button>
            </div>
          </form>
        </div>

        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
            <p className="mt-4 text-muted-foreground">Loading destinations...</p>
          </div>
        ) : destinations.length === 0 ? (
          <div className="text-center py-20">
            <MapPin className="h-16 w-16 mx-auto text-muted-foreground/50 mb-4" />
            <h3 className="text-xl font-semibold mb-2">No destinations found</h3>
            <p className="text-muted-foreground mb-6">
              {searchQuery ? 'Try a different search term' : 'Check back soon for new destinations'}
            </p>
            {searchQuery && (
              <Button 
                onClick={() => {
                  setSearchQuery("");
                  fetchDestinations();
                }}
                variant="outline"
              >
                Clear Search
              </Button>
            )}
          </div>
        ) : (
          <>
            <div className="mb-6 text-center text-muted-foreground">
              Found {destinations.length} destination{destinations.length !== 1 ? 's' : ''}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {destinations.map((dest) => (
                <div key={dest.id} className="animate-in fade-in slide-in-from-bottom-5 duration-500">
                  <DestinationCard {...dest} rating={parseFloat(dest.rating)} />
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
