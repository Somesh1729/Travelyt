import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import Navbar from "@/components/navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useUser } from "@/contexts/user-context";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Users, DollarSign, MapPin, Clock, CheckCircle2 } from "lucide-react";

export default function BookingPage() {
  const [, params] = useRoute("/booking/:id");
  const [location, setLocation] = useLocation();
  const { user } = useUser();
  const { toast } = useToast();
  
  const [destination, setDestination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    startDate: "",
    endDate: "",
    guests: 2,
    specialRequests: ""
  });

  useEffect(() => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to book a trip",
        variant: "destructive"
      });
      setLocation("/auth");
      return;
    }

    if (params?.id) {
      fetchDestination(params.id);
    }
  }, [params?.id, user]);

  async function fetchDestination(id) {
    try {
      const response = await fetch(`/api/destinations/${id}`);
      if (!response.ok) {
        throw new Error('Destination not found');
      }
      const data = await response.json();
      setDestination(data.destination);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load destination details",
        variant: "destructive"
      });
      setLocation("/destinations");
    } finally {
      setLoading(false);
    }
  }

  const calculateTotal = () => {
    if (!destination || !formData.startDate || !formData.endDate) return 0;
    
    const start = new Date(formData.startDate);
    const end = new Date(formData.endDate);
    const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    
    return destination.price * (days > 0 ? days : 0);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          destinationId: destination.id,
          ...formData,
          totalPrice: calculateTotal()
        })
      });

      if (!response.ok) {
        throw new Error('Booking failed');
      }

      toast({
        title: "Booking confirmed!",
        description: "Your trip has been successfully booked",
      });
      
      setLocation("/");
    } catch (error) {
      toast({
        title: "Booking failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-24 container mx-auto px-4 text-center py-20">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!destination) return null;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="pt-24 pb-20 container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-4xl font-bold mb-8 font-display">Complete Your Booking</h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Trip Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="startDate">Start Date</Label>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="startDate"
                            type="date"
                            value={formData.startDate}
                            onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                            className="pl-10"
                            required
                            min={new Date().toISOString().split('T')[0]}
                            data-testid="input-start-date"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="endDate">End Date</Label>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="endDate"
                            type="date"
                            value={formData.endDate}
                            onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                            className="pl-10"
                            required
                            min={formData.startDate || new Date().toISOString().split('T')[0]}
                            data-testid="input-end-date"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="guests">Number of Guests</Label>
                      <div className="relative">
                        <Users className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="guests"
                          type="number"
                          min="1"
                          max="10"
                          value={formData.guests}
                          onChange={(e) => setFormData({...formData, guests: parseInt(e.target.value)})}
                          className="pl-10"
                          required
                          data-testid="input-guests"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="specialRequests">Special Requests (Optional)</Label>
                      <Textarea
                        id="specialRequests"
                        placeholder="Any special requirements or requests..."
                        value={formData.specialRequests}
                        onChange={(e) => setFormData({...formData, specialRequests: e.target.value})}
                        rows={4}
                        data-testid="input-special-requests"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full" 
                      size="lg" 
                      disabled={submitting}
                      data-testid="button-confirm-booking"
                    >
                      {submitting ? "Processing..." : "Confirm Booking"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <img 
                      src={destination.image} 
                      alt={destination.title}
                      className="w-full h-48 object-cover rounded-lg mb-4"
                    />
                    <h3 className="font-bold text-lg mb-1">{destination.title}</h3>
                    <div className="flex items-center text-sm text-muted-foreground mb-4">
                      <MapPin className="h-4 w-4 mr-1" />
                      {destination.location}
                    </div>
                  </div>

                  <div className="border-t pt-4 space-y-3">
                    {destination.duration && (
                      <div className="flex items-center text-sm">
                        <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>{destination.duration}</span>
                      </div>
                    )}
                    <div className="flex items-center text-sm">
                      <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{formData.guests} {formData.guests === 1 ? 'guest' : 'guests'}</span>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-muted-foreground">Base Price</span>
                      <span className="font-medium">${destination.price}</span>
                    </div>
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm text-muted-foreground">Duration</span>
                      <span className="font-medium">
                        {formData.startDate && formData.endDate 
                          ? `${Math.ceil((new Date(formData.endDate) - new Date(formData.startDate)) / (1000 * 60 * 60 * 24))} days`
                          : '-'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pt-4 border-t">
                      <span className="text-lg font-bold">Total</span>
                      <span className="text-2xl font-bold text-primary">${calculateTotal()}</span>
                    </div>
                  </div>

                  {destination.included && destination.included.length > 0 && (
                    <div className="border-t pt-4">
                      <h4 className="font-semibold mb-3 text-sm">What's Included</h4>
                      <ul className="space-y-2">
                        {destination.included.map((item, index) => (
                          <li key={index} className="flex items-start text-sm text-muted-foreground">
                            <CheckCircle2 className="h-4 w-4 mr-2 text-green-500 flex-shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
