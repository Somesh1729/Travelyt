import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Plane, Menu, User as UserIcon, LogOut } from "lucide-react";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useUser } from "@/contexts/user-context";

export default function Navbar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const { user, logout } = useUser();

  const handleLogout = async () => {
    await logout();
    setIsOpen(false);
  };

  const NavLinks = () => (
    <>
      <Link href="/">
        <a className={`text-sm font-medium transition-colors hover:text-primary ${location === "/" ? "text-primary" : "text-muted-foreground"}`}>
          Home
        </a>
      </Link>
      <Link href="/destinations">
        <a className={`text-sm font-medium transition-colors hover:text-primary ${location === "/destinations" ? "text-primary" : "text-muted-foreground"}`}>
          Destinations
        </a>
      </Link>
      <Link href="/about">
        <a className={`text-sm font-medium transition-colors hover:text-primary ${location === "/about" ? "text-primary" : "text-muted-foreground"}`}>
          About
        </a>
      </Link>
    </>
  );

  return (
    <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-border/40 supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center gap-2 font-display font-bold text-xl tracking-tight text-primary">
            <Plane className="h-6 w-6" />
            TravelGenie
          </a>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <NavLinks />
        </div>

        <div className="hidden md:flex items-center gap-4">
          {user ? (
            <>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <UserIcon className="h-4 w-4" />
                <span data-testid="text-user-name">{user.firstName || user.username}</span>
              </div>
              <Button variant="ghost" className="font-medium" onClick={handleLogout} data-testid="button-logout">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </>
          ) : (
            <>
              <Link href="/auth">
                <Button variant="ghost" className="font-medium" data-testid="button-signin">Sign In</Button>
              </Link>
              <Link href="/auth?tab=register">
                <Button className="font-medium shadow-lg shadow-primary/20" data-testid="button-register-nav">Register</Button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Nav */}
        <div className="md:hidden">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col gap-6 mt-8">
                <NavLinks />
                <div className="flex flex-col gap-3 mt-4">
                  {user ? (
                    <>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground px-2">
                        <UserIcon className="h-4 w-4" />
                        <span>{user.firstName || user.username}</span>
                      </div>
                      <Button variant="outline" className="w-full" onClick={handleLogout}>
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </Button>
                    </>
                  ) : (
                    <>
                      <Link href="/auth">
                        <Button variant="outline" className="w-full">Sign In</Button>
                      </Link>
                      <Link href="/auth?tab=register">
                        <Button className="w-full">Register</Button>
                      </Link>
                    </>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
