import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MapPin, Calendar as CalendarIcon } from "lucide-react";
import heroImage from "@assets/generated_images/tropical_paradise_hero_background.png";

export default function Hero() {
  return (
    <div className="relative h-[600px] md:h-[700px] w-full overflow-hidden flex items-center justify-center">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-black/30 backdrop-blur-[1px]" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-3xl mx-auto space-y-6 animate-in slide-in-from-bottom-10 fade-in duration-700">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white text-sm font-medium mb-2">
            AI-Powered Travel Planning
          </span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-white leading-tight text-shadow">
            Discover Your Next <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-yellow-300">Adventure</span>
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto leading-relaxed">
            Let TravelGenie curate the perfect itinerary for you. Explore hidden gems, book seamless stays, and create memories that last a lifetime.
          </p>

          {/* Search Bar */}
          <div className="mt-8 p-2 bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl max-w-2xl mx-auto flex flex-col md:flex-row gap-2">
            <div className="flex-1 relative group">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-5 w-5 group-focus-within:text-primary transition-colors" />
              <Input 
                placeholder="Where to?" 
                className="pl-10 border-0 bg-transparent h-12 text-base focus-visible:ring-0 placeholder:text-muted-foreground/70" 
              />
            </div>
            <div className="w-px bg-border hidden md:block" />
            <div className="flex-1 relative group">
              <CalendarIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-5 w-5 group-focus-within:text-primary transition-colors" />
              <Input 
                placeholder="When?" 
                className="pl-10 border-0 bg-transparent h-12 text-base focus-visible:ring-0 placeholder:text-muted-foreground/70" 
              />
            </div>
            <Button size="lg" className="h-12 px-8 text-base font-semibold shadow-md hover:shadow-lg transition-all">
              <Search className="mr-2 h-5 w-5" />
              Search
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
