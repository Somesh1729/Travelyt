import { Link } from "wouter";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Star, Heart } from "lucide-react";

export default function DestinationCard({ id, image, title, location, price, rating, featured }) {
  return (
    <Card className="group overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 h-full flex flex-col bg-card">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        <Button 
          variant="secondary" 
          size="icon" 
          className="absolute top-3 right-3 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0 bg-white/90 hover:bg-white text-destructive hover:text-destructive"
        >
          <Heart className="h-5 w-5 fill-current" />
        </Button>

        {featured && (
          <Badge className="absolute top-3 left-3 bg-secondary text-secondary-foreground hover:bg-secondary/90">
            Featured
          </Badge>
        )}
      </div>
      
      <CardContent className="flex-1 p-5">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 mr-1 text-primary" />
            {location}
          </div>
          <div className="flex items-center text-amber-500 font-medium text-sm">
            <Star className="h-4 w-4 mr-1 fill-current" />
            {rating}
          </div>
        </div>
        <h3 className="font-display font-bold text-xl mb-2 line-clamp-1 group-hover:text-primary transition-colors">{title}</h3>
      </CardContent>
      
      <CardFooter className="p-5 pt-0 flex items-center justify-between border-t border-border/50 mt-auto bg-muted/20">
        <div>
          <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Starts at</span>
          <div className="text-lg font-bold text-primary">${price}</div>
        </div>
        <Link href={`/booking/${id}`}>
          <Button variant="outline" className="hover:bg-primary hover:text-primary-foreground transition-colors" data-testid={`button-view-details-${id}`}>
            View Details
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
