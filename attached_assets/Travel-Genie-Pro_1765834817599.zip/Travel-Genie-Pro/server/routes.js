import { createServer } from "http";
import { storage } from "./storage.js";
import { insertUserSchema, insertBookingSchema } from "../shared/schema.ts";
import { hashPassword, ensureAuthenticated } from "./auth.js";
import passport from "./auth.js";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(httpServer, app) {
  app.post("/api/auth/register", async (req, res, next) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }

      const hashedPassword = await hashPassword(validatedData.password);
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
      });

      const { password, ...userWithoutPassword } = user;

      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        res.json({ user: userWithoutPassword });
      });
    } catch (error) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).toString() });
      }
      next(error);
    }
  });

  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }

      req.login(user, (err) => {
        if (err) {
          return next(err);
        }

        const { password, ...userWithoutPassword } = user;
        res.json({ user: userWithoutPassword });
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const { password, ...userWithoutPassword } = req.user;
    res.json({ user: userWithoutPassword });
  });

  app.get("/api/destinations", async (req, res, next) => {
    try {
      const { search, featured } = req.query;
      
      let destinations;
      if (featured === 'true') {
        destinations = await storage.getFeaturedDestinations();
      } else if (search) {
        destinations = await storage.searchDestinations(search);
      } else {
        destinations = await storage.getAllDestinations();
      }

      res.json({ destinations });
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/destinations/:id", async (req, res, next) => {
    try {
      const destination = await storage.getDestination(req.params.id);
      
      if (!destination) {
        return res.status(404).json({ message: "Destination not found" });
      }

      res.json({ destination });
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/bookings", ensureAuthenticated, async (req, res, next) => {
    try {
      const bookings = await storage.getUserBookings(req.user.id);
      res.json({ bookings });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/bookings", ensureAuthenticated, async (req, res, next) => {
    try {
      const validatedData = insertBookingSchema.parse({
        ...req.body,
        userId: req.user.id,
      });

      const booking = await storage.createBooking(validatedData);
      res.json({ booking });
    } catch (error) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).toString() });
      }
      next(error);
    }
  });

  app.get("/api/bookings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const booking = await storage.getBooking(req.params.id);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }

      if (booking.booking.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      res.json({ booking });
    } catch (error) {
      next(error);
    }
  });

  return httpServer;
}
