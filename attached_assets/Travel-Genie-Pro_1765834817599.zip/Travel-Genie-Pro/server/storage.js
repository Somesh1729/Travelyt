import { db } from './db.js';
import { users, destinations, bookings } from '../shared/schema.ts';
import { eq, like, or, sql } from 'drizzle-orm';

export class Storage {
  async getUser(id) {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username) {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email) {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(insertUser) {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getAllDestinations() {
    return await db.select().from(destinations);
  }

  async getDestination(id) {
    const result = await db.select().from(destinations).where(eq(destinations.id, id));
    return result[0];
  }

  async searchDestinations(query) {
    if (!query) {
      return await this.getAllDestinations();
    }
    
    return await db.select()
      .from(destinations)
      .where(
        or(
          like(destinations.title, `%${query}%`),
          like(destinations.location, `%${query}%`),
          like(destinations.description, `%${query}%`)
        )
      );
  }

  async getFeaturedDestinations() {
    return await db.select().from(destinations).where(eq(destinations.featured, true));
  }

  async createDestination(insertDestination) {
    const result = await db.insert(destinations).values(insertDestination).returning();
    return result[0];
  }

  async getUserBookings(userId) {
    return await db.select({
      booking: bookings,
      destination: destinations
    })
    .from(bookings)
    .leftJoin(destinations, eq(bookings.destinationId, destinations.id))
    .where(eq(bookings.userId, userId));
  }

  async getBooking(id) {
    const result = await db.select({
      booking: bookings,
      destination: destinations
    })
    .from(bookings)
    .leftJoin(destinations, eq(bookings.destinationId, destinations.id))
    .where(eq(bookings.id, id));
    return result[0];
  }

  async createBooking(insertBooking) {
    const result = await db.insert(bookings).values(insertBooking).returning();
    return result[0];
  }

  async updateBookingStatus(id, status) {
    const result = await db.update(bookings)
      .set({ status })
      .where(eq(bookings.id, id))
      .returning();
    return result[0];
  }
}

export const storage = new Storage();
