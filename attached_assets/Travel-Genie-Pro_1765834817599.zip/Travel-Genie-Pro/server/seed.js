import { storage } from './storage.js';

const destinationsData = [
  {
    title: "Romantic Paris Getaway",
    location: "Paris, France",
    description: "Experience the magic of Paris with visits to the Eiffel Tower, Louvre Museum, and charming cafes along the Seine. Enjoy romantic walks through Montmartre and indulge in world-class French cuisine.",
    price: 1299,
    rating: "4.8",
    image: "/attached_assets/generated_images/eiffel_tower_paris_street_view.png",
    featured: true,
    duration: "5 days / 4 nights",
    highlights: [
      "Eiffel Tower evening visit with champagne",
      "Guided tour of the Louvre Museum",
      "Seine River cruise with dinner",
      "Day trip to Versailles Palace"
    ],
    included: [
      "4-star hotel accommodation",
      "Daily breakfast",
      "Airport transfers",
      "Professional tour guide"
    ]
  },
  {
    title: "Spiritual Bali Retreat",
    location: "Bali, Indonesia",
    description: "Discover inner peace in Bali's lush landscapes. Visit ancient temples, practice yoga overlooking rice terraces, and rejuvenate with traditional Balinese spa treatments.",
    price: 899,
    rating: "4.9",
    image: "/attached_assets/generated_images/balinese_temple_gate_landscape.png",
    featured: true,
    duration: "7 days / 6 nights",
    highlights: [
      "Daily yoga and meditation sessions",
      "Temple tours: Tanah Lot and Uluwatu",
      "Traditional Balinese massage",
      "Rice terrace trekking in Ubud"
    ],
    included: [
      "Luxury resort with pool villa",
      "All meals included",
      "Airport transfers",
      "Wellness activities and spa treatments"
    ]
  },
  {
    title: "Neon Nights in Tokyo",
    location: "Tokyo, Japan",
    description: "Immerse yourself in Tokyo's vibrant culture, from bustling Shibuya to serene temples. Experience cutting-edge technology, traditional tea ceremonies, and unforgettable street food.",
    price: 1599,
    rating: "4.7",
    image: "/attached_assets/generated_images/tokyo_neon_street_night.png",
    featured: false,
    duration: "6 days / 5 nights",
    highlights: [
      "Explore Shibuya and Harajuku districts",
      "Visit historic Senso-ji Temple",
      "Experience traditional tea ceremony",
      "Day trip to Mount Fuji"
    ],
    included: [
      "Centrally located 4-star hotel",
      "Daily breakfast",
      "JR Pass for local trains",
      "English-speaking guide"
    ]
  },
  {
    title: "Santorini Sunset Dreams",
    location: "Santorini, Greece",
    description: "Fall in love with Santorini's iconic white-washed buildings and stunning sunsets. Explore volcanic beaches, taste local wines, and sail the crystal-clear Aegean Sea.",
    price: 1199,
    rating: "4.9",
    image: "/attached_assets/generated_images/santorini_greece_white_buildings.png",
    featured: true,
    duration: "5 days / 4 nights",
    highlights: [
      "Sunset viewing in Oia village",
      "Private catamaran cruise",
      "Wine tasting at local vineyard",
      "Volcanic beach exploration"
    ],
    included: [
      "Cave hotel with caldera view",
      "Daily breakfast",
      "Airport transfers",
      "Sunset cruise with dinner"
    ]
  }
];

async function seedDatabase() {
  console.log('Starting database seed...');
  
  try {
    for (const dest of destinationsData) {
      await storage.createDestination(dest);
      console.log(`✓ Created destination: ${dest.title}`);
    }
    
    console.log('Database seeded successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
